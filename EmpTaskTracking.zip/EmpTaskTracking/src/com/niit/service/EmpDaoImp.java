/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.niit.service;

import com.niit.connect.ConnectClass;
import com.niit.connect.EmpDao;
import com.niit.entity.Employee;
import com.niit.entity.TrackMain;
import java.sql.*;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class EmpDaoImp implements EmpDao
{
    Employee emp=null;
    Connection con=null;
    PreparedStatement pstmt;
    public EmpDaoImp() {
        ConnectClass c=ConnectClass.getInstance();
        try {
            con=ConnectClass.getConnection();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(TrackMain.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(EmpDaoImp.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    
    @Override
    public List<Employee> getAllEmp() {
        
        List<Employee> empList=new ArrayList<>();
        String query="select * from employee";
        try {
            pstmt=con.prepareStatement(query);
            ResultSet rs=pstmt.executeQuery();
            System.out.println("Working");
            while(rs.next())
            {
                System.out.println("hi");
                int id=rs.getInt(1);
                String nm=rs.getString(2);
                Employee e=new Employee(id,nm);
                empList.add(e);
            }
        } catch (SQLException ex) {
            Logger.getLogger(EmpDaoImp.class.getName()).log(Level.SEVERE, null, ex);
        }
        return empList;
    }

    @Override
    public Employee getBookById(int id) {
        
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM employee WHERE id=" + id);
            if(rs.next())
            {
                Employee emp = new Employee();
                
                return emp;
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    //return null;
        
        return emp;
    }

    @Override
    public void saveEmp(Employee e) 
    {
        try {
        PreparedStatement ps = con.prepareStatement("INSERT INTO emp VALUES (?,?)");
        ps.setString(1, e.getName());
        ps.setInt(1, e.getEmpId());
        int i = ps.executeUpdate();
      if(i == 1) {
          System.out.println("Done");
      }
    } catch (SQLException ex) {
        ex.printStackTrace();
    }
    
    }

    @Override
    public void deleteEmp(Employee e) {
        try {
        Statement stmt = con.createStatement();
        int i = stmt.executeUpdate("DELETE FROM user WHERE id=" + e.getEmpId());
      if(i == 1) {
            System.out.println("done");
      }
    } catch (SQLException ex) {
        ex.printStackTrace();
    }

    }
    
}
