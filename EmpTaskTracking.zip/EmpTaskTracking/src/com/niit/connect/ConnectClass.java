
package com.niit.connect;
import java.sql.*;
public class ConnectClass {
    
    private static ConnectClass con=null;

    private ConnectClass() {
    }
    
    public static ConnectClass getInstance()
    {
         if (con==null)  
         {  
              con=new  ConnectClass();
         }  
         return con;  
    }
    
    public static Connection getConnection()throws ClassNotFoundException, SQLException  
    {  
                
              Connection con=null;  
              Class.forName("oracle.jdbc.driver.OracleDriver");  
              con= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "sys as sysdba", "password");  
              return con;  
                
    }  
    
}
