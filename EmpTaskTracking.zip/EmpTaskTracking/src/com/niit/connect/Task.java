
package com.niit.connect;


public class Task 
{
    int taskNo;
    String taskName;

    public Task(int taskNo, String taskName) {
        this.taskNo = taskNo;
        this.taskName = taskName;
    }

    public int getTaskNo() {
        return taskNo;
    }

    public void setTaskNo(int taskNo) {
        this.taskNo = taskNo;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }
    
    
}
