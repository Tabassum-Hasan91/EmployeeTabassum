
package com.niit.connect;

import com.niit.entity.Employee;
import java.util.List;


public interface EmpDao {
    List<Employee> getAllEmp();
    Employee getBookById(int id);
    void saveEmp(Employee e);
    void deleteEmp(Employee e);

   
}
