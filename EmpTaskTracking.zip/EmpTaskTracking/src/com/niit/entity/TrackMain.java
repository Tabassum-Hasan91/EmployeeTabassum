package com.niit.entity;


import com.niit.connect.ConnectClass;
import com.niit.service.EmpDaoImp;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;


public class TrackMain 
{
    public void dispEmp()
    {
        System.out.println("All employees are:");
        EmpDaoImp e=new EmpDaoImp();
        List<Employee> li=e.getAllEmp();
        System.out.println(li);
        
    }
    
    
    public static void main(String[] args) throws SQLException {
        
        EmpDaoImp edao=new  EmpDaoImp();
        //give the menu 
        Scanner s=new Scanner(System.in);
        System.out.println("Welocme to employee task tracker");
        System.out.println("Enter employee number to be tracked:");
        int empId=s.nextInt();

        System.out.println("Enter 1 for select All 2 for insert 3 for delete;");
        int choice=s.nextInt();

        switch(choice)
        {
            case 1:
//                System.out.println("Enter emp id and name to insert");
//                int id=s.nextInt();
//                
//                edao.saveEmp(e);
//                break;
            case 2:
                System.out.println("Enter emp id to delete");
                Employee e=new Employee();
                        
                int id1=s.nextInt();
                String name=s.next();
                e.setEmpId(id1);
                e.setName(name);
                edao.saveEmp(e);
                break;
                
                
        }
                
        
        
        
                
               
                
        
    }
    
    
    
    
}
